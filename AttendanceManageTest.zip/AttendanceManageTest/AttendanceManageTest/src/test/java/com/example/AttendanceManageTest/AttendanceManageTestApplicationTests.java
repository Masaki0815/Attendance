package com.example.AttendanceManageTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AttendanceManageTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
