package com.example.AttendanceManageTest.mapper;

import org.apache.ibatis.annotations.Mapper;
import com.example.AttendanceManageTest.entity.UserEntity;

@Mapper
public interface  UserMapper {
    UserEntity findByUsername(String username);
}