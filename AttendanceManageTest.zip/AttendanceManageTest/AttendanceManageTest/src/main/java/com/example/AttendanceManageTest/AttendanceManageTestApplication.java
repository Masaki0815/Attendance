package com.example.AttendanceManageTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AttendanceManageTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(AttendanceManageTestApplication.class, args);
	}

}
