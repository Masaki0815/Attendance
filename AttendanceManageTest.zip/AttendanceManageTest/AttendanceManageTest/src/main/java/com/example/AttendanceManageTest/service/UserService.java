package com.example.AttendanceManageTest.service;

import com.example.AttendanceManageTest.entity.UserEntity;
import com.example.AttendanceManageTest.mapper.UserMapper;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    private final UserMapper userMapper;

    public UserService(UserMapper userMapper) {
        this.userMapper = userMapper;
    }

    public UserEntity getUserByUsername(String username) {
        return userMapper.findByUsername(username);
    }
}